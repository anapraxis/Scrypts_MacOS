#!/bin/bash

##### Монтируем облака в локальные папки
rclone --vfs-cache-mode writes mount 15GB_nost79: /Volumes/Data/clouds/GDisk/nost79/root/15GB_nost79/ &
rclone --vfs-cache-mode writes mount unlim_yaakoubi_edu: /Volumes/Data/clouds/GDisk/nost79/unlim/unlim_yaakoubi_edu/ &
rclone --vfs-cache-mode writes mount 15GB_akuby333: /Volumes/Data/clouds/GDisk/akuby333/root/15GB_akuby333/ &
rclone --vfs-cache-mode writes mount 5TB_onedrive_akuby333: /Volumes/Data/clouds/onedrive/5TB_onedrive_akuby333/ &
rclone --vfs-cache-mode writes mount 5TB_onedrive_mikhail2: /Volumes/Data/clouds/onedrive/5TB_onedrive_mikhail2/ &
rclone --vfs-cache-mode writes mount 5GB_onedrive_nost79: /Volumes/Data/clouds/onedrive/5GB_onedrive_nost79/  &
rclone --vfs-cache-mode writes mount 5TB_onedrive_cmannino1: /Volumes/Data/clouds/onedrive/5TB_onedrive_cmannino1/  &
rclone --vfs-cache-mode writes mount 280GB_yandex_mapostolov: /Volumes/Data/clouds/yandex/280GB_yandex_mapostolov/ &
rclone --vfs-cache-mode writes mount 10GB_yandex_mikhail_apostolov_pro: /Volumes/Data/clouds/yandex/10GB_yandex_mikhail_apostolov_pro/ &
rclone --vfs-cache-mode writes mount webdav_nextcloud_apostolov_pro: /Volumes/Data/clouds/nextcloud/anapraxis/ &
rclone --vfs-cache-mode writes mount 50GB_MEGA: /Volumes/Data/clouds/MEGA/50GB_MEGA/ &
rclone --vfs-cache-mode writes mount 8GB_mailru_m_apostolov: /Volumes/Data/clouds/mail_ru/8GB_mailru_m_apostolov &
rclone --vfs-cache-mode writes mount 100GB_mailru_nost79: /Volumes/Data/clouds/mail_ru/100GB_mailru_nost79 &
rclone --vfs-cache-mode writes mount secret_8GB_mailru_m_apostolov: /Volumes/Data/clouds/mail_ru/secret_8GB_mailru_m_apostolov &
rclone --vfs-cache-mode writes mount secret_100GB_mailru_nost79: /Volumes/Data/clouds/mail_ru/secret_100GB_mailru_nost79 &
rclone --vfs-cache-mode writes mount secret_15GB_akuby333: /Volumes/Data/clouds/GDisk/akuby333/root/secret_15GB_akuby333 &
rclone --vfs-cache-mode writes mount secret_15GB_nost79: /Volumes/Data/clouds/GDisk/nost79/root/secret_15GB_nost79 &
rclone --vfs-cache-mode writes mount secret_280GB_yandex_mapostolov: /Volumes/Data/clouds/yandex/secret_280GB_yandex_mapostolov &
rclone --vfs-cache-mode writes mount secret_8GB_mailru_m_apostolov: /Volumes/Data/clouds/mail_ru/secret_8GB_mailru_m_apostolov &
rclone --vfs-cache-mode writes mount secret_unlim_yaakoubi_edu: /Volumes/Data/clouds/GDisk/nost79/unlim/secret_unlim_yaakoubi_edu &
rclone --vfs-cache-mode writes mount secret_50GB_MEGA: /Volumes/Data/clouds/MEGA/secret_50GB_MEGA &

exit
