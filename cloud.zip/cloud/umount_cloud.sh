#!/bin/bash

##### Монтируем облака в локальные папки
umount -f  /Volumes/Data/clouds/GDisk/nost79/root/15GB_nost79/
umount -f  /Volumes/Data/clouds/GDisk/nost79/unlim/unlim_yaakoubi_edu/
umount -f  /Volumes/Data/clouds/GDisk/akuby333/root/15GB_akuby333/
umount -f  /Volumes/Data/clouds/onedrive/5TB_onedrive_akuby333/
umount -f  /Volumes/Data/clouds/onedrive/5TB_onedrive_mikhail2/
umount -f  /Volumes/Data/clouds/onedrive/5GB_onedrive_nost79/
umount -f  /Volumes/Data/clouds/onedrive/5TB_onedrive_cmannino1/
umount -f  /Volumes/Data/clouds/yandex/280GB_yandex_mapostolov/
umount -f  /Volumes/Data/clouds/yandex/10GB_yandex_mikhail_apostolov_pro/
umount -f  /Volumes/Data/clouds/nextcloud/anapraxis/
umount -f  /Volumes/Data/clouds/MEGA/50GB_MEGA/
umount -f  /Volumes/Data/clouds/GDisk/akuby333/root/secret_15GB_akuby333
umount -f  /Volumes/Data/clouds/GDisk/nost79/root/secret_15GB_nost79
umount -f  /Volumes/Data/clouds/yandex/secret_280GB_yandex_mapostolov
umount -f  /Volumes/Data/clouds/mail_ru/secret_8GB_mailru_m_apostolov
umount -f  /Volumes/Data/clouds/mail_ru/secret_100GB_mailru_nost79
umount -f  /Volumes/Data/clouds/GDisk/nost79/unlim/secret_unlim_yaakoubi_edu
umount -f  /Volumes/Data/clouds/MEGA/secret_50GB_MEGA

exit
