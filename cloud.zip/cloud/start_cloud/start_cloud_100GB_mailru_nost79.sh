#!/bin/bash

rclone --vfs-cache-mode writes mount 100GB_mailru_nost79: /Volumes/Data/clouds/mail_ru/100GB_mailru_nost79 &

exit
