#!/bin/bash

rclone --vfs-cache-mode writes mount 5TB_onedrive_cmannino1: /Volumes/Data/clouds/onedrive/5TB_onedrive_cmannino1/  &

exit
