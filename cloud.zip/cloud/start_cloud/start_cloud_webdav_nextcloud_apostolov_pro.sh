#!/bin/bash

rclone --vfs-cache-mode writes mount webdav_nextcloud_apostolov_pro: /Volumes/Data/clouds/nextcloud/anapraxis/ &

exit
