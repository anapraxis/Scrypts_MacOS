#!/bin/bash

rclone --vfs-cache-mode writes mount secret_100GB_mailru_nost79: /Volumes/Data/clouds/mail_ru/secret_100GB_mailru_nost79 &

exit
