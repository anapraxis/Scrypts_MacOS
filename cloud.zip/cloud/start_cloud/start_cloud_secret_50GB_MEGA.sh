#!/bin/bash

rclone --vfs-cache-mode writes cmount secret_50GB_MEGA: /Volumes/Data/clouds/MEGA/secret_50GB_MEGA &

exit
