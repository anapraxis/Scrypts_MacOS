#!/bin/bash

rclone --vfs-cache-mode writes mount secret_280GB_yandex_mapostolov: /Volumes/Data/clouds/yandex/secret_280GB_yandex_mapostolov &

exit
