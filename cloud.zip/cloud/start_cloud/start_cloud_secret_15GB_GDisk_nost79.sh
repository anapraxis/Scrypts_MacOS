#!/bin/bash

rclone --vfs-cache-mode writes mount secret_15GB_nost79: /Volumes/Data/clouds/GDisk/nost79/root/secret_15GB_nost79 &

exit
