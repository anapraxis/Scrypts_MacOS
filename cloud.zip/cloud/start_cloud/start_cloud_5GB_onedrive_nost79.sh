#!/bin/bash

rclone --vfs-cache-mode writes mount 5GB_onedrive_nost79: /Volumes/Data/clouds/onedrive/5GB_onedrive_nost79/  &

exit
