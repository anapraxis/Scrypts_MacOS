#!/bin/bash

rclone --vfs-cache-mode writes mount unlim_yaakoubi_edu: /Volumes/Data/clouds/GDisk/nost79/unlim/unlim_yaakoubi_edu/ &

exit
