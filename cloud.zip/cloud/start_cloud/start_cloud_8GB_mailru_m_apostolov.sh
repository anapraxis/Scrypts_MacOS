#!/bin/bash

rclone --vfs-cache-mode writes mount 8GB_mailru_m_apostolov: /Volumes/Data/clouds/mail_ru/8GB_mailru_m_apostolov &

exit
