#!/bin/bash

rclone --vfs-cache-mode writes mount 50GB_MEGA: /Volumes/Data/clouds/MEGA/50GB_MEGA/ &

exit
