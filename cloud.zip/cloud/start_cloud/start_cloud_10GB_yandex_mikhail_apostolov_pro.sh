#!/bin/bash

rclone --vfs-cache-mode writes mount 10GB_yandex_mikhail_apostolov_pro: /Volumes/Data/clouds/yandex/10GB_yandex_mikhail_apostolov_pro/ &

exit
