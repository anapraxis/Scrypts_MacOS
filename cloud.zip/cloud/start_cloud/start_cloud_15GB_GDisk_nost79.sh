#!/bin/bash

rclone --vfs-cache-mode writes mount 15GB_nost79: /Volumes/Data/clouds/GDisk/nost79/root/15GB_nost79/ &

exit
