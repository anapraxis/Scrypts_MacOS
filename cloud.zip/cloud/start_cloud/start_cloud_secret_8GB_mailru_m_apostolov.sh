#!/bin/bash

rclone --vfs-cache-mode writes mount secret_8GB_mailru_m_apostolov: /Volumes/Data/clouds/mail_ru/secret_8GB_mailru_m_apostolov &

exit
