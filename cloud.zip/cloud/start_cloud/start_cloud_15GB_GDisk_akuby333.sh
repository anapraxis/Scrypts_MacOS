#!/bin/bash

rclone --vfs-cache-mode writes mount 15GB_akuby333: /Volumes/Data/clouds/GDisk/akuby333/root/15GB_akuby333/ &

exit
