#!/bin/bash

rclone --vfs-cache-mode writes mount secret_15GB_akuby333: /Volumes/Data/clouds/GDisk/akuby333/root/secret_15GB_akuby333 &

exit
