#!/bin/bash

umount -f /Volumes/Data/clouds/mail_ru/secret_8GB_mailru_m_apostolov

exit
