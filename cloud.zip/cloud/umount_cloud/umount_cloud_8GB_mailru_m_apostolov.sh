#!/bin/bash

umount -f /Volumes/Data/clouds/mail_ru/8GB_mailru_m_apostolov

exit
