#!/bin/bash

umount -f /Volumes/Data/clouds/mail_ru/secret_100GB_mailru_nost79

exit
