#!/bin/bash

umount -f /Volumes/Data/clouds/MEGA/secret_50GB_MEGA

exit
