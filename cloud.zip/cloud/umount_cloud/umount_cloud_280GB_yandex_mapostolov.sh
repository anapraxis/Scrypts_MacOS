#!/bin/bash

umount -f /Volumes/Data/clouds/yandex/280GB_yandex_mapostolov/

exit
