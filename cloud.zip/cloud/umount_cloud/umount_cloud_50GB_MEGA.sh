#!/bin/bash

umount -f /Volumes/Data/clouds/MEGA/50GB_MEGA/

exit
