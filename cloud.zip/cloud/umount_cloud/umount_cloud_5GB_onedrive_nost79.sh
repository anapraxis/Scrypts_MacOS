#!/bin/bash

umount -f /Volumes/Data/clouds/onedrive/5GB_onedrive_nost79/

exit
