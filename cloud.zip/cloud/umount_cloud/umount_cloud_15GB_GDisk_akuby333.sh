#!/bin/bash

umount -f /Volumes/Data/clouds/GDisk/akuby333/root/15GB_akuby333/

exit
