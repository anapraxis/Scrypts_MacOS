#!/bin/bash

umount -f /Volumes/Data/clouds/GDisk/nost79/unlim/unlim_yaakoubi_edu/

exit
