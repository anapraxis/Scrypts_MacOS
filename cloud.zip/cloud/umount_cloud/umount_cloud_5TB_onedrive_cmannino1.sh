#!/bin/bash

umount -f /Volumes/Data/clouds/onedrive/5TB_onedrive_cmannino1/

exit
