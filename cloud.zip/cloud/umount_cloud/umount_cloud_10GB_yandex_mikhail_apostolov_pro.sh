#!/bin/bash

umount -f /Volumes/Data/clouds/yandex/10GB_yandex_mikhail_apostolov_pro/

exit
