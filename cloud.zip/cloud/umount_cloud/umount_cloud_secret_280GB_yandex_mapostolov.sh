#!/bin/bash

umount -f /Volumes/Data/clouds/yandex/secret_280GB_yandex_mapostolov

exit
