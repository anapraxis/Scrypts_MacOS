#!/bin/bash

umount -f /Volumes/Data/clouds/nextcloud/anapraxis/

exit
