#!/bin/bash

umount -f /Volumes/Data/clouds/GDisk/nost79/root/secret_15GB_nost79

exit
