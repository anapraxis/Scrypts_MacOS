#!/bin/bash

umount -f /Volumes/Data/clouds/GDisk/nost79/root/15GB_nost79/

exit
